#include "atmel_start.h"
#include "atmel_start_pins.h"
#include "adp_main.h"
#include <wolfssl/wolfcrypt/settings.h>
#include <wolfcrypt/test/test.h>

typedef struct func_args {
	int    argc;
	char** argv;
	int    return_code;
} func_args;

int main(void)
{
	func_args args;
	
	atmel_start_init();

	spi_m_sync_enable(&EDBG_SPI);
	adp_app_init();
	adp_interface_init_spi(&EDBG_SPI.io, EDBG_SPI_SS_PIN);
	ADP_example();
	wolfcrypt_test(&args);
}
