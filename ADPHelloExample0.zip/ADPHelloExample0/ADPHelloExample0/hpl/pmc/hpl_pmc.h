/**
 * \file
 *
 * \brief Power Management Controller register vG related functionality.
 *
 * Copyright (C) 2017 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */

#ifndef _HPL_PMC_V71_H_INCLUDED
#define _HPL_PMC_V71_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#define PLL_COUNT 0x3fU

#ifndef PMC_PCR_GCLKEN
#define PMC_PCR_GCLKEN (0x1u << 29)
#endif

#ifndef PMC_PCR_GCLKDIV
#define PMC_PCR_GCLKDIV_Pos 20
#define PMC_PCR_GCLKDIV_Msk (0xffu << PMC_PCR_GCLKDIV_Pos)
#define PMC_PCR_GCLKDIV(value) ((PMC_PCR_GCLKDIV_Msk & ((value) << PMC_PCR_GCLKDIV_Pos)))
#endif

#ifndef PMC_PCR_GCLKCSS
#define PMC_PCR_GCLKCSS_Pos 8
#define PMC_PCR_GCLKCSS_Msk (0x07u << PMC_PCR_GCLKCSS_Pos)
#define PMC_PCR_GCLKCSS(value) ((PMC_PCR_GCLKCSS_Msk & ((value) << PMC_PCR_GCLKCSS_Pos)))
#endif

/**
 * \brief Initializes cortex M7 core clock
 *
 */
void _pmc_init(void);

/**
 * \brief Enable the specified peripheral clock.
 *
 * \note The ID must not be shifted (i.e., 1 << ID_xxx).
 *
 * \param periph_id Peripheral ID
 *
 */
static inline void _pmc_enable_periph_clock(uint32_t periph_id)
{
	if (periph_id < 32) {
		if (!hri_pmc_get_PCSR0_reg(PMC, (1 << periph_id))) {
			hri_pmc_set_PCSR0_reg(PMC, (1 << periph_id));
		}
	} else {
		periph_id -= 32;
		if (!hri_pmc_get_PCSR1_reg(PMC, (1 << periph_id))) {
			hri_pmc_set_PCSR1_reg(PMC, (1 << periph_id));
		}
	}
}

/**
 * \brief Disable the specified peripheral clock.
 *
 * \note The ID must not be shifted (i.e., 1 << ID_xxx).
 *
 * \param periph_id Peripheral ID
 *
 */
static inline void _pmc_disable_periph_clock(uint32_t periph_id)
{
	if (periph_id < 32) {
		if (hri_pmc_get_PCSR0_reg(PMC, (1 << periph_id))) {
			hri_pmc_clear_PCSR0_reg(PMC, (1 << periph_id));
		}
	} else {
		periph_id -= 32;
		if (hri_pmc_get_PCSR1_reg(PMC, (1 << periph_id))) {
			hri_pmc_clear_PCSR1_reg(PMC, (1 << periph_id));
		}
	}
}

/**
 * \brief Enable the gclk clock of I2SC.
 *
 * \note The ID must not be shifted (i.e., 1 << ID_xxx).
 *
 * \param periph_id Peripheral ID
 * \param gclk_css  Generic Clock Source Selection
 * \param gclk_div  Generic Clock Division Ratio. Generic clock is the selected
 *                  clock period divided by GCLKDIV + 1.
 *
 */
static inline void _pmc_enable_gclk_clock(uint32_t periph_id, uint8_t gclk_css, uint8_t gclk_div)
{
	hri_pmc_write_PCR_reg(PMC, PMC_PCR_PID(periph_id));
	if (!(hri_pmc_read_PCR_reg(PMC) & PMC_PCR_EN)) {
		hri_pmc_write_PCR_reg(PMC,
		                      (PMC_PCR_GCLKEN | PMC_PCR_EN | PMC_PCR_CMD | PMC_PCR_GCLKDIV(gclk_div - 1)
		                       | PMC_PCR_GCLKCSS(gclk_css)
		                       | PMC_PCR_PID(periph_id)));
	}
}

/**
 * \brief Disable the gclk clock of I2SC.
 *
 * \note The ID must not be shifted (i.e., 1 << ID_xxx).
 *
 * \param periph_id Peripheral ID
 *
 */
static inline void _pmc_disable_gclk_clock(uint32_t periph_id)
{
	hri_pmc_write_PCR_reg(PMC, PMC_PCR_PID(periph_id));
	if ((hri_pmc_read_PCR_reg(PMC) & PMC_PCR_EN)) {
		hri_pmc_write_PCR_reg(PMC, (PMC_PCR_CMD | PMC_PCR_PID(periph_id)));
	}
}

#ifdef __cplusplus
}
#endif

#endif
